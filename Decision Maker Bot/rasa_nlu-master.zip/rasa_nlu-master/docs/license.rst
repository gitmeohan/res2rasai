
License
=======


.. literalinclude:: ../LICENSE.txt